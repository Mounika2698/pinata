import React, { useState } from "react";
import axios from "axios";
const FormData = require("form-data");

const Pinata = () => {
  const [imgData, setImgData] = useState("");

  const onChange = (file) => {
    setImgData(file);
  };

  const sendFileToIPFS = async (e) => {
    console.log("inside");
    let data = new FormData();
    data.append("file", imgData);
    //api
    const resFile = await axios({
      method: "post",
      url: "https://api.pinata.cloud/pinning/pinFileToIPFS",
      data,
      headers: {
        pinata_api_key: `${process.env.REACT_APP_PINATA_API_KEY}`,
        pinata_secret_api_key: `${process.env.REACT_APP_PINATA_API_SECRET}`,
        "Content-Type": `multipart/form-data; boundary= ${imgData._boundary}`,
        Authorization: `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySW5mb3JtYXRpb24iOnsiaWQiOiJiZDE4Zjc3NS0xOWQ2LTQyY2MtODBjNi0wNjc0MGVhODE3YTUiLCJlbWFpbCI6ImFqaXRoamVybWE0MkBnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwicGluX3BvbGljeSI6eyJyZWdpb25zIjpbeyJpZCI6IkZSQTEiLCJkZXNpcmVkUmVwbGljYXRpb25Db3VudCI6MX0seyJpZCI6Ik5ZQzEiLCJkZXNpcmVkUmVwbGljYXRpb25Db3VudCI6MX1dLCJ2ZXJzaW9uIjoxfSwibWZhX2VuYWJsZWQiOmZhbHNlLCJzdGF0dXMiOiJBQ1RJVkUifSwiYXV0aGVudGljYXRpb25UeXBlIjoic2NvcGVkS2V5Iiwic2NvcGVkS2V5S2V5IjoiMzM3ZTI4Njc5MzgwZWQ4Nzc0OTAiLCJzY29wZWRLZXlTZWNyZXQiOiIxOTJhMzk3ODkzM2UwMGE4OTdhN2NjNzJmZTI3MGQ0OWMxMjk3YmEyMzUzNzliYWRjZjhlZWQyNGIzZTIxN2MyIiwiaWF0IjoxNjY0ODgwMDIyfQ.brDnNSkspV6OuBaZbOD22ftup3jYYmixDdUoJKqq0OA`,
      },
    }).then((res) => {
      data = new FormData();
     console.log(res.data);
    });
  };

  return (
    <div>
      <img width="200" height="200" alt="avatar" />
      <input
        type="file"
        onChange={(event) => onChange(event.target.files[0] || null)}
      />
      <button onClick={sendFileToIPFS}>Minting</button>
    </div>
  );
};

export default Pinata;
