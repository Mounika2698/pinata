

// imports needed for this function
const axios = require('axios');
// const fs = require('fs-extra');
// const fs = require('fs').promises;
const FormData = require('form-data');


//   const testAuthentication = () => {
//     const url = `https://api.pinata.cloud/data/testAuthentication`;
//     return axios
//         .get(url, {
//             headers: {
//                 'pinata_api_key': "337e28679380ed877490",
//                 'pinata_secret_api_key': "192a3978933e00a897a7cc72fe270d49c1297ba235379badcf8eed24b3e217c2"
//             }
//         })
//         .then(function (response) {
//           console.log(response)
//             //handle your response here
//         })
//         .catch(function (error) {
//           console.log(error)
//             //handle error here
//         });
// };

// export default testAuthentication;

const pinFileToIPFS = () => {
    const url = `https://api.pinata.cloud/pinning/pinJSONToIPFS`;
//we gather a local file from the API for this example, but you can gather the file from anywhere
    let data = new FormData();
    // data.append('file', fs.createReadStream('./yourfile.png',"input.txt"));
return axios.post(url,
        data,
        {
            headers: {
                'Content-Type': `multipart/form-data; boundary= ${data._boundary}`,
                'pinata_api_key': "337e28679380ed877490",
                'pinata_secret_api_key': "192a3978933e00a897a7cc72fe270d49c1297ba235379badcf8eed24b3e217c2",
                
            }
        }
    ).then(function (response) {
        console.log(response)
    }).catch(function (error) {
       console.log(error,"err")
    });

};

export default pinFileToIPFS

