import "./App.css";
import React, { useState } from "react";
import axios from "axios";
const Buffer = require('buffer').Buffer 
const {
  Readable,

} = require('readable-stream')

const App = () => {
  const [fileImg, setFileImg] = useState(null);

  const handleChange = (e)=>{
    console.log("e",e)
    const data = e.replace && e.replace(/^data:image\/png;base64,/, "");
console.log(data,"data")
    setFileImg(e)
  }
  const sendFileToIPFS = async (e) => {
// console.log(e,"E")
    // const data = e.replace(/^data:image\/png;base64,/, "");
    const buff = Buffer.from(fileImg,"base64");
    console.log("buff",buff)
    const stream = Readable.from(buff);
    // console.log(stream,"stream")
    stream.path = "some_filename.png";

//api
const resFile = await axios({
  method: "post",
  url: "https://api.pinata.cloud/pinning/pinFileToIPFS",
  data: "str.png",
  headers: {
    pinata_api_key: `${process.env.REACT_APP_PINATA_API_KEY}`,
    pinata_secret_api_key: `${process.env.REACT_APP_PINATA_API_SECRET}`,
    "Content-Type": "multipart/form-data"
  }
  }).pinFileToIPFS(stream);

    // ¡¡ THE HACK !!
   
    // const res = await pinata.pinFileToIPFS(stream);

    console.log(resFile.data)
    return resFile.IpfsHash;
  
    // console.log(e)
    // if (fileImg) {
    //   console.log("fileImg",fileImg)
    //   try {
    //     const formData = new FormData();
    //     console.log("formData",formData)
    //     const dataForm = formData.append("file", fileImg);
        
    //     })

    //     console.log("resFile", resFile.data);
    //     const ImgHash = `ipfs : ${resFile.data.IpfsHash}`;
    //     console.log(ImgHash,"ImgHash");
    //     //Take a look at your Pinata Pinned section, you will see a new file added to you list.
    //   } catch (error) {
    //     console.log("Error sending File to IPFS: ");
    //     console.log(error);
    //   }
    // }
  };

  return (
    <>
      {/* <form onSubmit={sendFileToIPFS}> */}
        <input
          type="file"
          onChange={(e) => handleChange(e.target.files[0])}
          required
        />
        <button type="submit" onClick={sendFileToIPFS}>Mint NFT</button>
      {/* </form> */}
    </>
  );
};

export default App;
