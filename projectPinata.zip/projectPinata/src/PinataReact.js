import { React,useState } from "react";
import axios from "axios";



const Pinata = () => {
  const[uploading,setUploading] = useState(false);
  const [image,setImage] = useState()
const token = ""

  const uploadFileHandler = async (e) => {
    // console.log(e,"e")
    const formData = new FormData();
    const reader = new FileReader();
    // console.log(reader,"reader")
    if (e.target.files[0]) {
         reader.readAsDataURL(e.target.files[0]);
       }
    reader.onload = (readerEvent) => {
    // console.log(readerEvent,"readerEvent")

    formData.append("image", readerEvent.target.result);
   };
    setUploading(true);
    
    // try {
    //   const config = {
    //     headers: {
    //       pinata_api_key: "337e28679380ed877490",
    //       pinata_secret_api_key: "192a3978933e00a897a7cc72fe270d49c1297ba235379badcf8eed24b3e217c2",
    //       "Content-Type": "multipart/form-data"
    //     },
    //   };

      fetch("https://api.pinata.cloud/pinning/pinFileToIPFS", {
        method: "POST",
     
    // Adding body or contents to send
    body: JSON.stringify({
        file: "ajith.jpg",
        
    }),
     
    // Adding headers to the request
    headers: {
      pinata_api_key: "337e28679380ed877490",
       pinata_secret_api_key: "192a3978933e00a897a7cc72fe270d49c1297ba235379badcf8eed24b3e217c2",
      "Content-Type": "multipart/form-data",
      'Access-Control-Allow-Origin':'*',
      Authorization: `Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VySW5mb3JtYXRpb24iOnsiaWQiOiJiZDE4Zjc3NS0xOWQ2LTQyY2MtODBjNi0wNjc0MGVhODE3YTUiLCJlbWFpbCI6ImFqaXRoamVybWE0MkBnbWFpbC5jb20iLCJlbWFpbF92ZXJpZmllZCI6dHJ1ZSwicGluX3BvbGljeSI6eyJyZWdpb25zIjpbeyJpZCI6IkZSQTEiLCJkZXNpcmVkUmVwbGljYXRpb25Db3VudCI6MX0seyJpZCI6Ik5ZQzEiLCJkZXNpcmVkUmVwbGljYXRpb25Db3VudCI6MX1dLCJ2ZXJzaW9uIjoxfSwibWZhX2VuYWJsZWQiOmZhbHNlLCJzdGF0dXMiOiJBQ1RJVkUifSwiYXV0aGVudGljYXRpb25UeXBlIjoic2NvcGVkS2V5Iiwic2NvcGVkS2V5S2V5IjoiMzM3ZTI4Njc5MzgwZWQ4Nzc0OTAiLCJzY29wZWRLZXlTZWNyZXQiOiIxOTJhMzk3ODkzM2UwMGE4OTdhN2NjNzJmZTI3MGQ0OWMxMjk3YmEyMzUzNzliYWRjZjhlZWQyNGIzZTIxN2MyIiwiaWF0IjoxNjY0ODgwMDIyfQ.brDnNSkspV6OuBaZbOD22ftup3jYYmixDdUoJKqq0OA`
    }
      })
.then(data => {
    console.log(data,"data")
})
.catch(err => {
    console.log(err)
})
    
    //   const { data } = await fetch(
    //     "https://api.pinata.cloud/pinning/pinFileToIPFS",
    //     formData,
    //     config
    //   );
    //   console.log(data,"res.data")
    //   setImage(data);
    //   setUploading(false);
    // } 
    // catch (error) {
    //   console.log(error)
    // }

  
  }
  return (
    <>
    <input
                style={{ height: "calc(2em + 0.75rem + 2px)" }}
                accept="*"
                type="file"
                id="images"
                placeholder="Choose Featured Images"
                value={image}
                onChange={uploadFileHandler}
              />
               {uploading && (
                <div className="spinner-border text-primary" role="status">
                  <span className="sr-only">Loading...</span>
                </div>
              )}
    </>
  )
}



export default Pinata